# 企点营销云 CDP React Native SDK 混淆规则
-keep class com.tencent.qidian.cdp.analytics.** { *; }
