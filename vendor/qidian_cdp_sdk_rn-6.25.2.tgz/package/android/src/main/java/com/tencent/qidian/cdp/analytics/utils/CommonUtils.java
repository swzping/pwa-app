package com.tencent.qidian.cdp.analytics.utils;

import android.util.Log;

import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeArray;
import com.facebook.react.bridge.WritableNativeMap;
import com.tencent.cdp.autotrack.AutoTrackEventType;

import org.json.JSONArray;
import org.json.JSONObject;


public class CommonUtils {

    private static final String LOG_TAG = "CDPAnalytics";

    /**
     * 将 ReadableMap 转换为 JSONObject（支持嵌套 Map 和 Array）
     *
     * @param readableMap RN 桥接传入的 ReadableMap 对象
     * @return 转换后的 JSONObject，若入参为 null 则返回空 JSONObject
     */
    public static JSONObject readableMapToJson(ReadableMap readableMap) {
        JSONObject jsonObject = new JSONObject();
        if (readableMap == null) {
            return jsonObject;
        }
        try {
            ReadableMapKeySetIterator iterator = readableMap.keySetIterator();
            while (iterator.hasNextKey()) {
                String key = iterator.nextKey();
                switch (readableMap.getType(key)) {
                    case String:
                        jsonObject.put(key, readableMap.getString(key));
                        break;
                    case Boolean:
                        jsonObject.put(key, readableMap.getBoolean(key));
                        break;
                    case Number:
                        jsonObject.put(key, readableMap.getDouble(key));
                        break;
                    case Map:
                        jsonObject.put(key, readableMapToJson(readableMap.getMap(key)));
                        break;
                    case Array:
                        jsonObject.put(key, readableArrayToJson(readableMap.getArray(key)));
                        break;
                    case Null:
                        jsonObject.put(key, JSONObject.NULL);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "readableMapToJson error: " + e.toString());
        }
        return jsonObject;
    }

    /**
     * 将 RN 层的单个 AutoTrackEventType 值转换为 Android 层的 AutoTrackEventType
     *
     * RN 端值定义：
     *   AppStart     = 1 << 1  (2)
     *   AppExit      = 1 << 2  (4)
     *   AppPageOpen  = 1 << 3  (8)
     *   AppPageClose = 1 << 4  (16)
     *   AppClick     = 1 << 5  (32)
     *   All          = 1 << 6  (64)
     * @param rnEventType RN 端传入的单个自动埋点事件类型值
     * @return 对应的 Android AutoTrackEventType，无匹配时返回 null
     */
    public static AutoTrackEventType convertAutoTrackEventType(int rnEventType) {
        switch (rnEventType) {
            case 1 << 1:
                return AutoTrackEventType.APP_START;
            case 1 << 2:
                return AutoTrackEventType.APP_END;
            case 1 << 3:
                return AutoTrackEventType.APP_PAGE_VIEW;
            case 1 << 4:
                return AutoTrackEventType.APP_PAGE_CLOSE;
            case 1 << 5:
                return AutoTrackEventType.APP_CLICK;
            default:
                Log.w(LOG_TAG, "Unknown RN AutoTrackEventType: " + rnEventType);
                return null;
        }
    }

    /**
     * 将 ReadableArray 转换为 JSONArray（支持嵌套 Map 和 Array）
     *
     * @param readableArray RN 桥接传入的 ReadableArray 对象
     * @return 转换后的 JSONArray，若入参为 null 则返回空 JSONArray
     */
    public static JSONArray readableArrayToJson(ReadableArray readableArray) {
        JSONArray jsonArray = new JSONArray();
        try {
            if (readableArray == null) return jsonArray;
            for (int i = 0; i < readableArray.size(); i++) {
                switch (readableArray.getType(i)) {
                    case String:
                        jsonArray.put(readableArray.getString(i));
                        break;
                    case Boolean:
                        jsonArray.put(readableArray.getBoolean(i));
                        break;
                    case Number:
                        jsonArray.put(readableArray.getDouble(i));
                        break;
                    case Map:
                        jsonArray.put(readableMapToJson(readableArray.getMap(i)));
                        break;
                    case Array:
                        jsonArray.put(readableArrayToJson(readableArray.getArray(i)));
                        break;
                    case Null:
                        jsonArray.put(JSONObject.NULL);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "readableArrayToJson error: " + e.toString());
        }
        return jsonArray;
    }

    /**
     * 将 JSONObject 转换为 WritableMap（支持嵌套 JSONObject 和 JSONArray）
     *
     * @param jsonObject SDK 返回的 JSONObject 对象
     * @return 转换后的 WritableMap，若入参为 null 则返回空 WritableNativeMap
     */
    public static WritableMap jsonToWritableMap(JSONObject jsonObject) {
        WritableMap writableMap = new WritableNativeMap();
        try {
            if (jsonObject == null) return writableMap;
            java.util.Iterator<String> keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object value = jsonObject.get(key);
                if (value == null || value == JSONObject.NULL) {
                    writableMap.putNull(key);
                } else if (value instanceof String) {
                    writableMap.putString(key, (String) value);
                } else if (value instanceof Boolean) {
                    writableMap.putBoolean(key, (Boolean) value);
                } else if (value instanceof Integer) {
                    writableMap.putInt(key, (Integer) value);
                } else if (value instanceof Double) {
                    writableMap.putDouble(key, (Double) value);
                } else if (value instanceof Long) {
                    writableMap.putDouble(key, ((Long) value).doubleValue());
                } else if (value instanceof Float) {
                    writableMap.putDouble(key, ((Float) value).doubleValue());
                } else if (value instanceof JSONObject) {
                    writableMap.putMap(key, jsonToWritableMap((JSONObject) value));
                } else if (value instanceof JSONArray) {
                    writableMap.putArray(key, jsonArrayToWritableArray((JSONArray) value));
                }
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "jsonToWritableMap error: " + e.toString());
        }
        return writableMap;
    }

    /**
     * 将 JSONArray 转换为 WritableArray（支持嵌套 JSONObject 和 JSONArray）
     *
     * @param jsonArray SDK 返回的 JSONArray 对象
     * @return 转换后的 WritableArray，若入参为 null 则返回空 WritableNativeArray
     */
    public static WritableArray jsonArrayToWritableArray(JSONArray jsonArray) {
        WritableArray writableArray = new WritableNativeArray();
        try {
            if (jsonArray == null) return writableArray;
            for (int i = 0; i < jsonArray.length(); i++) {
                Object value = jsonArray.get(i);
                if (value == null || value == JSONObject.NULL) {
                    writableArray.pushNull();
                } else if (value instanceof String) {
                    writableArray.pushString((String) value);
                } else if (value instanceof Boolean) {
                    writableArray.pushBoolean((Boolean) value);
                } else if (value instanceof Integer) {
                    writableArray.pushInt((Integer) value);
                } else if (value instanceof Double) {
                    writableArray.pushDouble((Double) value);
                } else if (value instanceof Long) {
                    writableArray.pushDouble(((Long) value).doubleValue());
                } else if (value instanceof Float) {
                    writableArray.pushDouble(((Float) value).doubleValue());
                } else if (value instanceof JSONObject) {
                    writableArray.pushMap(jsonToWritableMap((JSONObject) value));
                } else if (value instanceof JSONArray) {
                    writableArray.pushArray(jsonArrayToWritableArray((JSONArray) value));
                }
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "jsonArrayToWritableArray error: " + e.toString());
        }
        return writableArray;
    }
}
