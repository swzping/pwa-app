/**
 * 企点营销云 CDP 数据采集 React Native SDK - Android 原生模块
 * Copyright © Tencent. All rights reserved.
 *
 * 参数类型映射关系：
 * String -> String
 * ReadableMap -> Object
 * Boolean -> Bool
 * Integer -> Number
 * Double -> Number
 * Float -> Number
 * Callback -> function
 * ReadableArray -> Array
 */

package com.tencent.qidian.cdp.analytics;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;

import com.tencent.cdp.CdpConfigOptions;
import com.tencent.cdp.QDAnalyticsSDK;
import com.tencent.cdp.autotrack.AutoTrackEventType;
import com.tencent.cdp.encrypt.EncryptType;
import com.tencent.cdp.util.NetworkUtils;
import com.tencent.qidian.cdp.analytics.utils.CommonUtils;

import org.json.JSONObject;

public class RNCDPAnalyticsModule extends ReactContextBaseJavaModule {

    private static final String MODULE_NAME = "RNCDPAnalyticsModule";
    private static final String LOG_TAG = "CDPAnalytics";
    // 版本号由 build.gradle 从 package.json 统一注入
    private static final String SDK_VERSION = BuildConfig.CDP_RN_SDK_VERSION;

    private boolean logEnabled = false;


    /**
     * 构造函数
     * @param reactContext React Native 应用上下文
     */
    public RNCDPAnalyticsModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    /**
     * 返回原生模块名称，JS 端通过此名称访问模块
     * @return 模块名称 "RNCDPAnalyticsModule"
     */
    @Override
    public String getName() {
        return MODULE_NAME;
    }

    // ==================== 初始化 ====================
    /**
     * 初始化 SDK
     * @param appKey 开发者在管理平台申请的 key
     * @param configMap 配置选项字典
     */
    @ReactMethod
    public void init(String appKey, ReadableMap configMap) {
        try {
            if (configMap != null && configMap.hasKey("logEnabled")) {
                this.logEnabled = configMap.getBoolean("logEnabled");
            }
            Activity activity = getCurrentActivity();
            if (activity == null) {
                logDebug("init error: Activity is null");
                return;
            }
            logDebug("SDK init params: " + CommonUtils.readableMapToJson(configMap).toString());
            if (!QDAnalyticsSDK.isInit()) {
                initSdk(activity, appKey, configMap);
                logDebug("SDK first initialization completed, appKey: " + appKey);
            } else {
                modifySdk(activity, appKey, configMap);
                logDebug("SDK configuration updated, appKey: " + appKey);
            }

            // Set account info
            initAccountInfo(configMap);
            // Set device ID
            initDeviceId(configMap);
        } catch (Exception e) {
            Log.e(LOG_TAG, "sdk init error: " + e.toString());
        }
    }

    /**
     * 首次初始化 SDK，创建配置并调用底层 SDK 初始化接口
     * @param activity 当前 Activity
     * @param appKey 开发者在管理平台申请的 key
     * @param configMap RN 端传入的配置选项字典
     */
    private void initSdk(Activity activity, String appKey, ReadableMap configMap) {
        // 初始化配置
        CdpConfigOptions configOptions = new CdpConfigOptions();

        // 上报地址
        if (configMap.hasKey("requestBaseUrl")) {
            configOptions.setServerUrl(configMap.getString("requestBaseUrl"));
        }

        // 上报事件类型
        if (configMap.hasKey("autoTrackEventType")) {
            initAutoTrackEventType(configOptions, configMap.getInt("autoTrackEventType"));
        }

        // 上报时间间隔（毫秒），默认15000ms，有效范围：5000ms ~ 600000ms
        if (configMap.hasKey("reportInterval")) {
            int interval = configMap.getInt("reportInterval");
            if (interval < 5000 || interval > 600000) {
                interval = 15000;
            }
            configOptions.setFlushInterval(interval);
        }

        // 本地缓存最大事件数（达到阈值时发送数据），默认100条，有效范围：0 ~ 1000
        if (configMap.hasKey("reportMaxSize")) {
            int size = configMap.getInt("reportMaxSize");
            if (size < 0 || size > 1000) {
                size = 100;
            }
            configOptions.setFlushBulkSize(size);
        }

        // 单次上报最大条数，默认50条，有效范围：20 ~ 100
        if (configMap.hasKey("singleReportMaxSize")) {
            int size = configMap.getInt("singleReportMaxSize");
            if (size < 20 || size > 100) {
                size = 50;
            }
            configOptions.setSendBulkSize(size);
        }

        // 本地缓存上限（字节），默认 32MB
        if (configMap.hasKey("maxCacheSizeAndroid")) {
            long cacheSize = (long) configMap.getDouble("maxCacheSizeAndroid");
            configOptions.setMaxCacheSize(cacheSize);
        } else {
            configOptions.setMaxCacheSize(32 * 1024 * 1024);
        }

        // 会话间隔时间，Android 端固定 0，不可通过 RN 层配置
        configOptions.setSessionIntervalTime(0);

        // 自定义语言
        if (configMap.hasKey("customLanguage")) {
            String customLanguage = configMap.getString("customLanguage");
            if (!TextUtils.isEmpty(customLanguage)) {
                configOptions.customLanguage(customLanguage);
            }
        }

        // 加密方式
        if (configMap.hasKey("encryptType")) {
            configOptions.setHttpEncryptType(mapEncryptType(configMap.getInt("encryptType")));
        }

        // GZIP 压缩
        if (configMap.hasKey("gzipEnabled")) {
            configOptions.enableGZIP(configMap.getBoolean("gzipEnabled"));
        }

        // 网络发送策略
        if (configMap.hasKey("flushNetworkPolicy")) {
            int rnNetworkPolicy = configMap.getInt("flushNetworkPolicy");
            int androidNetworkPolicy = mapFlushNetworkPolicy(rnNetworkPolicy);
            configOptions.setNetworkTypePolicy(androidNetworkPolicy);
        }

        // 日志开关
        if (configMap.hasKey("logEnabled")) {
            this.logEnabled = configMap.getBoolean("logEnabled");
            configOptions.enableLog(this.logEnabled);
        }

        // 禁用自动追踪 Fragment
        configOptions.disableAutoTrackFragment();

        QDAnalyticsSDK.getInstance().init(activity, appKey, configOptions);
    }

    /**
     * SDK 已初始化时更新配置，直接修改 SDK 实例的各项参数
     * @param activity 当前 Activity
     * @param appKey 开发者在管理平台申请的 key
     * @param configMap RN 端传入的配置选项字典
     */
    private void modifySdk(Activity activity, String appKey, ReadableMap configMap) {
        QDAnalyticsSDK sdkInstance = QDAnalyticsSDK.getInstance();

        // appKey
        sdkInstance.setAppKey(appKey);

        // 上报地址
        if (configMap.hasKey("requestBaseUrl")) {
            sdkInstance.setServerUrl(configMap.getString("requestBaseUrl"));
        }

        // 上报事件类型
        if (configMap.hasKey("autoTrackEventType")) {
            modifyAutoTrackTypes(configMap.getInt("autoTrackEventType"));
        }

        // 上报时间间隔（毫秒），有效范围：5000 ~ 600000
        if (configMap.hasKey("reportInterval")) {
            int interval = configMap.getInt("reportInterval");
            if (interval >= 5000 && interval <= 600000) {
                sdkInstance.setFlushInterval(interval);
            }
        }

        // 本地缓存最大事件数（达到阈值时发送数据），默认100条，有效范围：0 ~ 1000
        if (configMap.hasKey("reportMaxSize")) {
            int size = configMap.getInt("reportMaxSize");
            if (size >= 0 && size <= 1000) {
                sdkInstance.setFlushBulkSize(size);
            }
        }

        // 单次上报最大条数，默认50条，有效范围：20 ~ 100
        if (configMap.hasKey("singleReportMaxSize")) {
            int size = configMap.getInt("singleReportMaxSize");
            if (size >= 20 && size <= 100) {
                sdkInstance.setSendBulkSize(size);
            }
        }

        // 本地缓存上限（字节），最小值16MB
        if (configMap.hasKey("maxCacheSizeAndroid")) {
            long cacheSize = (long) configMap.getDouble("maxCacheSizeAndroid");
            if (cacheSize >= 16 * 1024 *1024) {
                sdkInstance.setMaxCacheSize(cacheSize);
            }
        }

        // 自定义语言
        if (configMap.hasKey("customLanguage")) {
            String customLanguage = configMap.getString("customLanguage");
            sdkInstance.setCustomLanguage(customLanguage);
        }

        // 加密方式
        if (configMap.hasKey("encryptType")) {
            sdkInstance.setHttpEncryptType(mapEncryptType(configMap.getInt("encryptType")));
        }

        // GZIP 压缩
        if(configMap.hasKey("gzipEnabled")) {
            sdkInstance.enableGZIP(configMap.getBoolean("gzipEnabled"));
        }

        // 日志开关
        if(configMap.hasKey("logEnabled")) {
            this.logEnabled = configMap.getBoolean("logEnabled");
            sdkInstance.enableLog(this.logEnabled);
        }
    }

    /**
     * 根据 RN 端的位掩码，在 CdpConfigOptions 上开启对应的自动埋点事件类型
     * @param configOptions SDK 配置对象
     * @param eventTypes RN 端传入的自动埋点事件类型位掩码
     */
    private void initAutoTrackEventType(CdpConfigOptions configOptions, int eventTypes) {
        boolean all = (eventTypes & (1 << 6)) != 0;
        if (all || (eventTypes & (1 << 1)) != 0) {
            configOptions.enableAutoTrackEventType(AutoTrackEventType.APP_START);
        }
        if (all || (eventTypes & (1 << 2)) != 0) {
            configOptions.enableAutoTrackEventType(AutoTrackEventType.APP_END);
        }
        if (all || (eventTypes & (1 << 3)) != 0) {
            configOptions.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_VIEW);
        }
        if (all || (eventTypes & (1 << 4)) != 0) {
            configOptions.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_CLOSE);
        }
        if (all || (eventTypes & (1 << 5)) != 0) {
            configOptions.enableAutoTrackEventType(AutoTrackEventType.APP_CLICK);
        }
    }

    /**
     * 从配置中提取用户身份信息并设置到 SDK
     * @param configMap RN 端传入的配置选项字典
     */
    private void initAccountInfo(ReadableMap configMap) {
        // 用户身份信息
        if (configMap.hasKey("userInfos")) {
            ReadableMap userInfosMap = configMap.getMap("userInfos");
            this.setUserInfos(userInfosMap);
        }
    }

    /**
     * 从配置中提取自定义设备 ID 并设置到 SDK
     * @param configMap RN 端传入的配置选项字典
     */
    private void initDeviceId(ReadableMap configMap) {
        // 自定义设备 ID
        if (configMap.hasKey("deviceId")) {
            String deviceId = configMap.getString("deviceId");
            if (!TextUtils.isEmpty(deviceId)) {
                QDAnalyticsSDK.getInstance().setDeviceId(deviceId);
            }
        }
    }


    // ==================== 事件追踪 ====================

    /**
     * 埋点事件上报
     */
    @ReactMethod
    public void track(String eventName, ReadableMap properties) {
        try {
            JSONObject jsonProps = CommonUtils.readableMapToJson(properties);
            // 标记为非自动追踪事件，防止底层 SDK 因缺少 isAutoTrackEvent 字段而抛出 JSONException
            if (!jsonProps.has("isAutoTrackEvent")) {
                jsonProps.put("isAutoTrackEvent", false);
            }
            logDebug("track event: " + eventName + ", properties: " + jsonProps.toString());
            QDAnalyticsSDK.getInstance().track(eventName, jsonProps);
        } catch (Exception e) {
            Log.e(LOG_TAG, "track error: " + e.toString());
        }
    }

    /**
     * 控件点击事件（自动追踪专用，供 CDPRNHook.js 注入的 $AppClick 代码调用）
     * @param properties 点击事件属性（element_type、element_content、element_path 等）
     *
     * 上报 $AppClick 事件前检查自动埋点开关。
     */
    @ReactMethod
    public void trackAppClick(ReadableMap properties) {
        try {
            // 检查 autoTrackEventType 开关，仅在 AppClick 开关开启时才上报
            if (!QDAnalyticsSDK.getInstance().isAutoTrackEventTypeEnable(AutoTrackEventType.APP_CLICK)) {
                logDebug("trackAppClick: $AppClick auto-track is disabled, skipping report");
                return;
            }

            JSONObject jsonProps = CommonUtils.readableMapToJson(properties);
            logDebug("trackAppClick: " + jsonProps.toString());
            jsonProps.put("isAutoTrackEvent", true);
            QDAnalyticsSDK.getInstance().track("$AppClick", jsonProps);
        } catch (Exception e) {
            Log.e(LOG_TAG, "trackAppClick error: " + e.toString());
        }
    }

    /**
     * 页面浏览/关闭事件（自动追踪专用，供 CDPRNHook.js 调用）
     * @param eventName 事件名称（$AppPageView 或 $AppPageClose）
     * @param rnProperties 页面属性
     */
    @ReactMethod
    public void trackViewScreen(String eventName, ReadableMap rnProperties) {
        try {
            // 检查 autoTrackEventType 开关，根据事件名称检查对应开关
            QDAnalyticsSDK sdk = QDAnalyticsSDK.getInstance();
            if ("$AppPageView".equals(eventName)) {
                if (!sdk.isAutoTrackEventTypeEnable(AutoTrackEventType.APP_PAGE_VIEW)) {
                    logDebug("trackViewScreen: $AppPageView auto-track is disabled, skipping report");
                    return;
                }
            } else if ("$AppPageClose".equals(eventName)) {
                if (!sdk.isAutoTrackEventTypeEnable(AutoTrackEventType.APP_PAGE_CLOSE)) {
                    logDebug("trackViewScreen: $AppPageClose auto-track is disabled, skipping report");
                    return;
                }
            } else {
                logDebug("trackViewScreen: unsupported event name " + eventName + ", skipping report");
                return;
            }

            JSONObject jsonProps = CommonUtils.readableMapToJson(rnProperties);
            logDebug("trackViewScreen: " + eventName + " props: " + jsonProps.toString());
            jsonProps.put("isAutoTrackEvent", true);
            sdk.track(eventName, jsonProps);

        } catch (Exception e) {
            Log.e(LOG_TAG, "trackViewScreen error: " + e.toString());
        }
    }

    // ==================== 事件属性管理 ====================

    /**
     * 清除事件的所有属性（公共属性，预置事件属性）
     */
    @ReactMethod
    public void cleanProperties(int rnEventType) {
        try {
            AutoTrackEventType eventType = CommonUtils.convertAutoTrackEventType(rnEventType);
            if (eventType == null) {
                QDAnalyticsSDK.getInstance().clearCommonProperties();
                logDebug("cleanProperties (clearCommonProperties)");
            } else {
                QDAnalyticsSDK.getInstance().clearAutoTrackEventProperties(eventType);
                logDebug("cleanProperties (clearAutoTrackEventProperties): rnEventType is " + rnEventType);
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "cleanProperties error: " + e.toString());
        }
    }

    /**
     * 新增事件属性（公共属性，预置事件属性）
     */
    @ReactMethod
    public void addProperties(ReadableMap properties, int rnEventType) {
        try {
            JSONObject jsonProps = CommonUtils.readableMapToJson(properties);
            if (jsonProps.length() == 0) {
                return;
            }
            AutoTrackEventType eventType = CommonUtils.convertAutoTrackEventType(rnEventType);
            if (eventType == null) {
                QDAnalyticsSDK.getInstance().registerCommonProperties(jsonProps);
                logDebug("addProperties (registerCommonProperties): " + jsonProps.toString());
            } else {
                QDAnalyticsSDK.getInstance().registerAutoTrackEventProperties(eventType, jsonProps);
                logDebug("addProperties (registerAutoTrackEventProperties): rnEventType is " + rnEventType + ", props: " + jsonProps.toString());
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "addProperties error: " + e.toString());
        }
    }

    /**
     * 删除事件的某一条属性
     */
    @ReactMethod
    public void removeProperty(String key, int rnEventType) {
        try {
            AutoTrackEventType eventType = CommonUtils.convertAutoTrackEventType(rnEventType);
            if (eventType == null) {
                QDAnalyticsSDK.getInstance().unregisterCommonProperty(key);
                logDebug("removeProperty (unregisterCommonProperty): " + key);
            } else {
                QDAnalyticsSDK.getInstance().unregisterAutoTrackEventProperty(eventType, key);
                logDebug("removeProperty (unregisterAutoTrackEventProperty): rnEventType is " + rnEventType + ", key: " + key);
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "removeProperty error: " + e.toString());
        }
    }

    /**
     * 获取事件的所有属性
     */
    @ReactMethod
    public void getProperties(int rnEventType, Promise promise) {
        try {
            AutoTrackEventType eventType = CommonUtils.convertAutoTrackEventType(rnEventType);
            JSONObject jsonProps;
            if (eventType == null) {
                jsonProps = QDAnalyticsSDK.getInstance().getCommonProperties();
                logDebug("getProperties (getCommonProperties): " + (jsonProps != null ? jsonProps.toString() : "null"));
            } else {
                jsonProps = QDAnalyticsSDK.getInstance().getAutoTrackEventProperties(eventType);
                logDebug("getProperties (getAutoTrackEventProperties): rnEventType is " + rnEventType + ", props: " + (jsonProps != null ? jsonProps.toString() : "null"));
            }
            WritableMap result = jsonProps != null ? CommonUtils.jsonToWritableMap(jsonProps) : new WritableNativeMap();
            promise.resolve(result);
        } catch (Exception e) {
            promise.reject("CDPAnalytics", "getProperties failed", e);
        }
    }

    // ==================== 自动埋点控制 ====================

    /**
     * 开启自动埋点
     */
    @ReactMethod
    public void enableAutoTrack(int rnEventType) {
        try {
            enableAutoTrackTypes(rnEventType);
            logDebug("enableAutoTrack type: " + rnEventType);
        } catch (Exception e) {
            Log.e(LOG_TAG, "enableAutoTrack error: " + e.toString());
        }
    }

    /**
     * 关闭自动埋点
     */
    @ReactMethod
    public void disableAutoTrack(int rnEventType) {
        try {
            disableAutoTrackTypes(rnEventType);
            logDebug("disableAutoTrack type: " + rnEventType);
        } catch (Exception e) {
            Log.e(LOG_TAG, "disableAutoTrack error: " + e.toString());
        }
    }

    // ==================== SDK 状态控制 ====================

    /**
     * 启用 SDK
     */
    @ReactMethod
    public void enableSDK() {
        try {
            QDAnalyticsSDK.enableSDK();
            logDebug("SDK enabled");
        } catch (Exception e) {
            Log.e(LOG_TAG, "enableSDK error: " + e.toString());
        }
    }

    /**
     * 禁用 SDK
     */
    @ReactMethod
    public void disableSDK() {
        try {
            QDAnalyticsSDK.disableSDK();
            logDebug("SDK disabled");
        } catch (Exception e) {
            Log.e(LOG_TAG, "disableSDK error: " + e.toString());
        }
    }

    /**
     * 获取 SDK 禁用状态
     */
    @ReactMethod
    public void isDisabled(Promise promise) {
        try {
            promise.resolve(QDAnalyticsSDK.isDisable());
        } catch (Exception e) {
            promise.reject("CDPAnalytics", "isDisabled failed", e);
        }
    }

    // ==================== 用户身份管理 ====================

    /**
     * 设置用户身份信息
     */
    @ReactMethod
    public void setUserInfos(ReadableMap userInfos) {
        try {
            JSONObject accountInfo = CommonUtils.readableMapToJson(userInfos);
            if (accountInfo.length() > 0) {
                QDAnalyticsSDK.getInstance().setAccount(accountInfo);
            }

            logDebug("setUserInfos (setAccount): " + accountInfo.toString());
        } catch (Exception e) {
            Log.e(LOG_TAG, "setUserInfos error: " + e.toString());
        }
    }

    /**
     * 获取 SDK 版本号
     */
    @ReactMethod
    public void getSDKVersion(Promise promise) {
        try {
            promise.resolve(SDK_VERSION);
        } catch (Exception e) {
            promise.reject("CDPAnalytics", "getSDKVersion failed", e);
        }
    }

    // ==================== 工具方法 ====================

    /**
     * 调试日志输出，仅在 logEnabled 为 true 时打印
     * @param message 日志内容
     */
    private void logDebug(String message) {
        if (logEnabled) {
            Log.d(LOG_TAG, message);
        }
    }

    /**
     * 将 RN 端 EncryptType 枚举值映射到 Android SDK 的 EncryptType
     * RN 端: BASE64=1, AES=2, NONE=3
     */
    private EncryptType mapEncryptType(int encryptTypeValue) {
        switch (encryptTypeValue) {
            case 1:
                return EncryptType.TYPE_BASE64;
            case 3:
                return EncryptType.TYPE_NONE;
            default:
                return EncryptType.TYPE_BASE64_AES;
        }
    }

    /**
     * 将 RN 端 flushNetworkPolicy 整数值（按位或组合）映射到 Android SDK 的 NetworkUtils.NetworkType
     * RN 端: NONE=0, TYPE_2G=1, TYPE_3G=2, TYPE_4G=4, TYPE_WIFI=8, TYPE_5G=16, TYPE_ALL=0xFF
     *
     * @param rnNetworkPolicy RN 端传入的网络策略值（各网络类型按位或的结果）
     * @return Android SDK 的网络策略值
     */
    private int mapFlushNetworkPolicy(int rnNetworkPolicy) {
        // RN 端 TYPE_ALL = 0xFF
        if (rnNetworkPolicy == 0xFF) {
            return NetworkUtils.NetworkType.TYPE_ALL;
        }

        int androidPolicy = NetworkUtils.NetworkType.TYPE_NONE;

        // RN 端 TYPE_2G = 1 (1 << 0)
        if ((rnNetworkPolicy & (1 << 0)) != 0) {
            androidPolicy |= NetworkUtils.NetworkType.TYPE_2G;
        }
        // RN 端 TYPE_3G = 2 (1 << 1)
        if ((rnNetworkPolicy & (1 << 1)) != 0) {
            androidPolicy |= NetworkUtils.NetworkType.TYPE_3G;
        }
        // RN 端 TYPE_4G = 4 (1 << 2)
        if ((rnNetworkPolicy & (1 << 2)) != 0) {
            androidPolicy |= NetworkUtils.NetworkType.TYPE_4G;
        }
        // RN 端 TYPE_WIFI = 8 (1 << 3)
        if ((rnNetworkPolicy & (1 << 3)) != 0) {
            androidPolicy |= NetworkUtils.NetworkType.TYPE_WIFI;
        }
        // RN 端 TYPE_5G = 16 (1 << 4)
        if ((rnNetworkPolicy & (1 << 4)) != 0) {
            androidPolicy |= NetworkUtils.NetworkType.TYPE_5G;
        }

        return androidPolicy;
    }



    /**
     * 根据 RN 端的 AutoTrackEventType 位掩码，开启对应的 Android 自动埋点事件
     *
     * RN 端枚举值（与 iOS 对齐）：
     *   AppStart     = 1 << 1  = 2
     *   AppExit      = 1 << 2  = 4
     *   AppPageOpen  = 1 << 3  = 8
     *   AppPageClose = 1 << 4  = 16
     *   AppClick     = 1 << 5  = 32
     *   All          = 1 << 6  = 64
     */
    private void modifyAutoTrackTypes(int eventTypeValue) {
        QDAnalyticsSDK sdk = QDAnalyticsSDK.getInstance();
        boolean all = (eventTypeValue & (1 << 6)) != 0;
        if (all || (eventTypeValue & (1 << 1)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_START);
        } else {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_START);
        }
        if (all || (eventTypeValue & (1 << 2)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_END);
        } else {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_END);
        }
        if (all || (eventTypeValue & (1 << 3)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_VIEW);
        } else {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_PAGE_VIEW);
        }
        if (all || (eventTypeValue & (1 << 4)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_CLOSE);
        } else {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_PAGE_CLOSE);
        }
        if (all || (eventTypeValue & (1 << 5)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_CLICK);
        } else {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_CLICK);
        }
    }

    /**
     * 根据 RN 端的 AutoTrackEventType 位掩码，开启对应的 Android 自动埋点事件
     */
    private void enableAutoTrackTypes(int eventTypeValue) {
        QDAnalyticsSDK sdk = QDAnalyticsSDK.getInstance();
        boolean all = (eventTypeValue & (1 << 6)) != 0;
        if (all || (eventTypeValue & (1 << 1)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_START);
        }
        if (all || (eventTypeValue & (1 << 2)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_END);
        }
        if (all || (eventTypeValue & (1 << 3)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_VIEW);
        }
        if (all || (eventTypeValue & (1 << 4)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_PAGE_CLOSE);
        }
        if (all || (eventTypeValue & (1 << 5)) != 0) {
            sdk.enableAutoTrackEventType(AutoTrackEventType.APP_CLICK);
        }
    }

    /**
     * 根据 RN 端的 AutoTrackEventType 位掩码，关闭对应的 Android 自动埋点事件
     */
    private void disableAutoTrackTypes(int eventTypeValue) {
        QDAnalyticsSDK sdk = QDAnalyticsSDK.getInstance();
        boolean all = (eventTypeValue & (1 << 6)) != 0;
        if (all || (eventTypeValue & (1 << 1)) != 0) {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_START);
        }
        if (all || (eventTypeValue & (1 << 2)) != 0) {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_END);
        }
        if (all || (eventTypeValue & (1 << 3)) != 0) {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_PAGE_VIEW);
        }
        if (all || (eventTypeValue & (1 << 4)) != 0) {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_PAGE_CLOSE);
        }
        if (all || (eventTypeValue & (1 << 5)) != 0) {
            sdk.disableAutoTrackEventType(AutoTrackEventType.APP_CLICK);
        }
    }

}
