/**
 * 企点营销云 CDP 数据采集 React Native SDK - Android Package
 * Copyright © Tencent. All rights reserved.
 */

package com.tencent.qidian.cdp.analytics;

import androidx.annotation.NonNull;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ReactPackage 注册原生 Bridge Module。
 */
public class RNCDPAnalyticsPackage implements ReactPackage {
    // 版本号由 build.gradle 从 package.json 统一注入
    public static final String VERSION = BuildConfig.CDP_RN_SDK_VERSION;

    @NonNull
    @Override
    public List<NativeModule> createNativeModules(@NonNull ReactApplicationContext reactContext) {
        List<NativeModule> modules = new ArrayList<>();
        modules.add(new RNCDPAnalyticsModule(reactContext));
        return modules;
    }

    @NonNull
    @Override
    public List<ViewManager> createViewManagers(@NonNull ReactApplicationContext reactContext) {
        return Collections.emptyList();
    }
}
