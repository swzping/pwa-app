/**
 * 企点营销云 CDP 数据采集 React Native SDK - 原生模块接口
 *
 * 使用旧架构（Bridge Module）与原生模块通信。
 */

import { NativeModules } from 'react-native';

/** 属性值类型（与 index.ts 中 PropertyValue 保持一致） */
type NativePropertyValue = string | number | boolean;

/** 原生模块方法签名 */
export interface RNCDPAnalyticsModuleSpec {
  /** 初始化 SDK */
  init(appKey: string, configOptions: object): void;
  /** 自定义事件上报 */
  track(eventName: string, properties: Record<string, NativePropertyValue>): void;
  /** 页面浏览事件上报（内部使用） */
  trackViewScreen(eventName: string, properties: Record<string, NativePropertyValue>): void;
  /** 控件点击事件上报（内部使用） */
  trackAppClick(properties: Record<string, NativePropertyValue>): void;
  /** 删除事件的所有属性 */
  cleanProperties(eventType: number): void;
  /** 给事件新增属性 */
  addProperties(properties: Record<string, NativePropertyValue>, eventType: number): void;
  /** 删除事件的某一条属性 */
  removeProperty(key: string, eventType: number): void;
  /** 获取事件的所有属性 */
  getProperties(eventType: number): Promise<Record<string, NativePropertyValue>>;
  /** 开启自动埋点 */
  enableAutoTrack(eventType: number): void;
  /** 关闭自动埋点 */
  disableAutoTrack(eventType: number): void;
  /** 启用 SDK */
  enableSDK(): void;
  /** 禁用 SDK */
  disableSDK(): void;
  /** 查询 SDK 是否已禁用 */
  isDisabled(): Promise<boolean>;
  /** 设置用户身份信息 */
  setUserInfos(userInfos: Record<string, string>): void;
  /** 获取 SDK 版本号 */
  getSDKVersion(): Promise<string>;
}

const CDPModule = NativeModules.RNCDPAnalyticsModule as RNCDPAnalyticsModuleSpec | undefined;

export default CDPModule;
