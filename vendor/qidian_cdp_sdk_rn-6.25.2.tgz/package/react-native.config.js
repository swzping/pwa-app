// react-native.config.js
module.exports = {
  dependency: {
    platforms: {
      ios: {},
      android: {
        sourceDir: './android',
        packageImportPath: 'import com.tencent.qidian.cdp.analytics.RNCDPAnalyticsPackage;',
        packageInstance: 'new RNCDPAnalyticsPackage()',
      },
    },
  },
};
