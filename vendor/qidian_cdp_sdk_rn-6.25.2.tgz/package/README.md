# 企点营销云 CDP 数据采集 React Native SDK

> `qidian_cdp_sdk_rn` — 企点营销云 CDP（Customer Data Platform）数据采集 React Native 跨平台插件，提供事件追踪、用户属性设置、自动埋点等数据采集功能。

---

## 兼容性

| 项目 | 要求 |
|------|------|
| React Native | 0.62.0 ~ 0.76.x |
| iOS 最低版本 | 13.0 |
| Android minSdkVersion | 21 |
| 导航库（自动页面追踪） | @react-navigation/native ^5.x ~ ^7.x |

---

## 安装

### 1. 安装 SDK

```bash
# 通过本地路径安装（tgz 包）
npm install /path/to/qidian_cdp_sdk_rn-x.y.z.tgz

# 或在 package.json 中指定本地路径
"dependencies": {
  "qidian_cdp_sdk_rn": "file:../qidian_cdp_sdk_rn"
}
```

### 2. 链接原生模块

SDK 支持 React Native auto-linking，安装后自动链接，无需手动配置。

**iOS 额外步骤：**

```bash
cd ios && pod install && cd ..
```

### 3. 自动埋点配置（自动完成）

SDK 在 `npm install` 时会自动执行 `postinstall` 脚本，完成自动埋点的配置：

- 如果项目使用了 `@react-navigation/native`，会自动启用**页面自动追踪**（`$AppPageView` / `$AppPageClose`）
- 会自动启用**控件点击自动追踪**（`$AppClick`），包括：
  - `TouchableOpacity`、`Pressable`、`Button` 等可点击组件（通过 Hook `Pressability.js`）
  - `Switch` 开关组件（通过 Hook `Switch.js`，因为 Android 上 Switch 不经过 Pressability 处理）

> 恢复被修改的文件：
> ```bash
> node node_modules/qidian_cdp_sdk_rn/CDPRNHook.js --reset
> ```

---

## 快速开始

### SDK 初始化

在应用入口处（如 `App.tsx`）初始化 SDK：

```typescript
import cdpAnalytics, {
  EncryptType,
  NetworkType,
  AutoTrackEventType,
} from 'qidian_cdp_sdk_rn';

cdpAnalytics.init('YOUR_APP_KEY', {
  requestBaseUrl: 'https://your-report-server.com/events/sdk/trace',
  autoTrackEventType: AutoTrackEventType.All,
  encryptType: EncryptType.BASE64_AES,
  flushNetworkPolicy: NetworkType.TYPE_4G | NetworkType.TYPE_WIFI | NetworkType.TYPE_5G,
  reportInterval: 15000,
  reportMaxSize: 100,
  logEnabled: true,
  userInfos: { uid: '12345' },
});
```

### 初始化参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `requestBaseUrl` | `string` | - | 数据上报服务地址 |
| `autoTrackEventType` | `AutoTrackEventType` | - | 自动埋点事件类型 |
| `encryptType` | `EncryptType` | `BASE64_AES` | 数据加密方式 |
| `flushNetworkPolicy` | `NetworkType` | - | 上报网络策略，支持位运算组合 |
| `reportInterval` | `number` | `15000` | 上报间隔（毫秒），最小 5000，最大 600000 |
| `reportMaxSize` | `number` | `100` | 本地缓存最大事件数目，达到阈值时发送，最小 0，最大 1000 |
| `singleReportMaxSize` | `number` | `50` | 单次上报最大条数，最小 20，最大 100 |
| `maxCacheSizeIOS` | `number` | `1000` | iOS 本地缓存上限（条数），最大 5000 |
| `maxCacheSizeAndroid` | `number` | `33554432` | Android 本地缓存上限（字节），默认 32MB，最小 16MB |
| `gzipEnabled` | `boolean` | - | 是否启用 Gzip 压缩 |
| `logEnabled` | `boolean` | `false` | 是否开启日志输出 |
| `deviceId` | `string` | - | 自定义设备 ID |
| `enableIdfa` | `boolean` | `true` | 是否启用 IDFA（仅 iOS） |
| `customLanguage` | `string` | - | 自定义语言标识，格式：`en_US`、`zh_CN` |
| `userInfos` | `Record<string, string>` | - | 用户身份信息 |

> **注意**：`maxCacheSizeIOS` 和 `maxCacheSizeAndroid` 分别针对不同平台的缓存上限策略。iOS 按条数计算，Android 按字节数计算。

---

## API 参考

### 事件追踪

#### `track(eventName, properties?)`

自定义埋点事件上报。

```typescript
// 上报自定义事件
cdpAnalytics.track('purchase', {
  item_id: 'SKU_001',
  item_name: '商品A',
  price: 99.9,
});
```

---

### 页面配置

为指定路由页面注册自定义标题和属性，自动追踪时会自动合并到 `$AppPageView` / `$AppPageClose` 事件中。

#### `registerPageConfig(routeName, config)`

```typescript
cdpAnalytics.registerPageConfig('ProductDetail', {
  pageTitle: '商品详情',
  pageProperties: { category: '电子产品', source: 'homepage' },
});
```

#### `unregisterPageConfig(routeName)`

取消页面配置。

```typescript
cdpAnalytics.unregisterPageConfig('ProductDetail');
```

#### `getPageConfig(routeName)`

查询页面配置。

```typescript
const config = cdpAnalytics.getPageConfig('ProductDetail');
```

---

### 控件自定义追踪属性

通过在 RN 组件的 props 中传递约定属性，为控件设置自定义 ID、自定义属性，或忽略上报。

```tsx
// 设置自定义元素 ID
<TouchableOpacity cdp_ViewId="buy_button" onPress={handleBuy}>
  <Text>购买</Text>
</TouchableOpacity>

// 设置自定义属性
<Pressable
  cdp_ViewId="product_card"
  cdp_Properties={{ item_id: '123', category: '电子产品' }}
  onPress={handleClick}>
  <Text>商品详情</Text>
</Pressable>

// 忽略该控件的上报
<TouchableOpacity cdp_isViewObjectIgnored={true} onPress={handleSomething}>
  <Text>不上报的按钮</Text>
</TouchableOpacity>

// Switch 组件同样支持
<Switch
  cdp_ViewId="notification_switch"
  cdp_isViewObjectIgnored={false}
  value={isEnabled}
  onValueChange={setIsEnabled}
/>
```

| Props | 类型 | 说明 |
|-------|------|------|
| `cdp_ViewId` | `string` | 自定义元素 ID，上报为 `element_id` 字段 |
| `cdp_Properties` | `Record<string, any>` | 自定义属性，合并到 `$AppClick` 事件中 |
| `cdp_isViewObjectIgnored` | `boolean` | 设为 `true` 时忽略该控件的点击上报 |

> **TypeScript 提示**：SDK 导出了 `CDPTrackProps` 类型接口，可在项目中扩展 `ViewProps` 以获得 IDE 提示。

> **技术说明**：`cdp_isViewObjectIgnored` 属性通过全局同步机制实现即时生效。在 React render 阶段，属性值会同步写入 `global.__cdp_ignored_map__`，绕过 React Fiber 双缓冲带来的延迟，确保开关切换后首次交互即可正确生效。

---

### 页面黑白名单

控制 `$AppPageView` 和 `$AppPageClose` 自动上报的范围。**白名单优先级高于黑名单**。

```typescript
// 忽略某些页面的 $AppPageView 上报
cdpAnalytics.ignoreAutoTrackAppPageViewPages(['Settings', 'Debug']);

// 只允许指定页面的 $AppPageView 上报（启用白名单后黑名单不生效）
cdpAnalytics.interestAutoTrackAppPageViewPages(['Home', 'ProductDetail']);

// $AppPageClose 也有独立的黑白名单
cdpAnalytics.ignoreAutoTrackAppPageClosePages(['Settings']);
```

#### $AppPageView 黑白名单

| 方法 | 说明 |
|------|------|
| `ignoreAutoTrackAppPageViewPages(pageNames)` | 将页面加入黑名单 |
| `resumeAutoTrackAppPageViewPages(pageNames)` | 从黑名单移除 |
| `interestAutoTrackAppPageViewPages(pageNames)` | 将页面加入白名单 |
| `boreAutoTrackAppPageViewPages(pageNames)` | 从白名单移除 |
| `isAutoTrackAppPageViewIgnored(pageName)` | 查询是否在黑名单中 |
| `isAutoTrackAppPageViewInterest(pageName)` | 查询是否在白名单中 |

#### $AppPageClose 黑白名单

| 方法 | 说明 |
|------|------|
| `ignoreAutoTrackAppPageClosePages(pageNames)` | 将页面加入黑名单 |
| `resumeAutoTrackAppPageClosePages(pageNames)` | 从黑名单移除 |
| `interestAutoTrackAppPageClosePages(pageNames)` | 将页面加入白名单 |
| `boreAutoTrackAppPageClosePages(pageNames)` | 从白名单移除 |
| `isAutoTrackAppPageCloseIgnored(pageName)` | 查询是否在黑名单中 |
| `isAutoTrackAppPageCloseInterest(pageName)` | 查询是否在白名单中 |

---

### 事件属性管理

| 方法 | 说明 |
|------|------|
| `addProperties(properties, eventType)` | 新增/覆盖事件属性 |
| `removeProperty(key, eventType)` | 删除单条事件属性 |
| `cleanProperties(eventType)` | 清除事件的所有属性 |
| `getProperties(eventType)` | 获取事件的所有属性（异步，返回 `Promise`） |

```typescript
// 为所有 AppClick 事件添加公共属性
cdpAnalytics.addProperties(
  { platform: 'rn', version: '2.0' },
  AutoTrackEventType.AppClick
);

// 获取属性
const props = await cdpAnalytics.getProperties(AutoTrackEventType.AppClick);
```

---

### 自动埋点控制

| 方法 | 说明 |
|------|------|
| `enableAutoTrack(eventType)` | 开启指定类型的自动埋点 |
| `disableAutoTrack(eventType)` | 关闭指定类型的自动埋点 |

```typescript
// 只关闭控件点击自动追踪，保留页面追踪
cdpAnalytics.disableAutoTrack(AutoTrackEventType.AppClick);
```

---

### SDK 控制

| 方法 | 说明 |
|------|------|
| `enableSDK()` | 启用 SDK |
| `disableSDK()` | 禁用 SDK（暂停所有数据采集和上报） |
| `isDisabled()` | 查询 SDK 禁用状态（异步，返回 `Promise<boolean>`） |
| `setUserInfos(userInfos)` | 设置/更新用户身份信息 |
| `getSDKVersion()` | 获取 SDK 版本号（异步，返回 `Promise<string>`） |

```typescript
// 更新用户身份
cdpAnalytics.setUserInfos({ uid: 'new_user_123', vip_level: 'gold' });

// 查询 SDK 版本
const version = await cdpAnalytics.getSDKVersion();
```

---

## 枚举类型

### AutoTrackEventType（自动埋点事件类型）

| 枚举值 | 数值 | 说明 |
|--------|------|------|
| `AppStart` | 2 | 应用启动事件 |
| `AppExit` | 4 | 应用退出事件 |
| `AppPageOpen` | 8 | 页面打开事件 |
| `AppPageClose` | 16 | 页面关闭事件 |
| `AppClick` | 32 | 控件点击事件 |
| `All` | 64 | 所有事件 |

> 支持位运算组合，例如 `AutoTrackEventType.AppStart | AutoTrackEventType.AppExit`

### EncryptType（数据加密方式）

| 枚举值 | 数值 | 说明 |
|--------|------|------|
| `BASE64` | 1 | Base64 编码 |
| `BASE64_AES` | 2 | 先 Base64 编码，再 AES 加密（推荐） |
| `NONE` | 3 | 不加密，明文传输 |

### NetworkType（网络类型）

| 枚举值 | 数值 | 说明 |
|--------|------|------|
| `NONE` | 0 | 无网络 |
| `TYPE_2G` | 1 | 2G |
| `TYPE_3G` | 2 | 3G |
| `TYPE_4G` | 4 | 4G |
| `TYPE_WIFI` | 8 | WIFI |
| `TYPE_5G` | 16 | 5G |
| `TYPE_ALL` | 255 | 所有网络 |

> 支持位运算组合，例如 `NetworkType.TYPE_4G | NetworkType.TYPE_WIFI | NetworkType.TYPE_5G`

---

## 自动采集说明

### $AppClick 控件点击事件

SDK 自动采集以下类型控件的点击事件：

| 控件类型 | Hook 方式 | 平台支持 |
|----------|-----------|----------|
| `TouchableOpacity` | Pressability.js | iOS / Android |
| `TouchableHighlight` | Pressability.js | iOS / Android |
| `TouchableWithoutFeedback` | Pressability.js | iOS / Android |
| `Pressable` | Pressability.js | iOS / Android |
| `Button` | Pressability.js | iOS / Android |
| `Text`（带 `onPress`） | Pressability.js | iOS / Android |
| `Switch` | Switch.js | iOS / Android |

`$AppClick` 事件自动采集以下字段：

| 字段 | 说明 |
|------|------|
| `element_type` | 组件类型名（如 `TouchableOpacity`、`Pressable`、`Switch`） |
| `element_content` | 控件的文本内容（Switch 为 `checked` / `unchecked`） |
| `element_path` | 组件在页面中的路径 |
| `element_id` | 自定义元素 ID（通过 `cdp_ViewId` 设置） |

> **Switch 组件说明**：React Native 的 Switch 在 Android 上不经过 `Pressability.js`，而是直接使用原生 `AndroidSwitchNativeComponent`。SDK 通过单独 Hook `Switch.js` 的 `handleChange` 函数实现跨平台统一采集。在 iOS 上，SDK 会自动忽略原生层对 `RCTSwitch`（`UISwitch`）的自动采集，由 JS 层统一处理，确保 `cdp_isViewObjectIgnored` 等 CDP 属性能正确生效。

### $AppPageView / $AppPageClose 页面浏览事件

页面自动追踪依赖 `@react-navigation/native`，自动采集以下字段：

| 字段 | 说明 |
|------|------|
| `url` | 路由名称 |
| `title` | 页面标题（通过 `registerPageConfig` 设置，默认为路由名称） |
| `referrer` | 上一个页面的路由名称 |
| `dr` | 页面停留时长（毫秒，仅 `$AppPageClose`） |

---

## 常见问题

### Q: 自动页面追踪没有生效？

确保项目安装了 `@react-navigation/native` ^5.x 及以上版本。SDK 在 `postinstall` 阶段会自动检测并配置页面追踪，如果安装 SDK 时尚未安装导航库，可以在安装导航库后重新执行：

```bash
node node_modules/qidian_cdp_sdk_rn/CDPRNHook.js
```

### Q: 如何恢复被自动修改的文件？

```bash
node node_modules/qidian_cdp_sdk_rn/CDPRNHook.js --reset
```

### Q: TypeScript 中 `cdp_ViewId` 等 props 报类型错误？

在项目中添加类型声明文件（如 `cdp.d.ts`）：

```typescript
import { CDPTrackProps } from 'qidian_cdp_sdk_rn';

declare module 'react-native' {
  interface ViewProps extends CDPTrackProps {}
}
```

### Q: Switch 组件在 Android 上的点击事件没有上报？

确认 Hook 脚本已正确执行。SDK 需要同时 Hook `Pressability.js`（处理 TouchableOpacity 等）和 `Switch.js`（处理 Switch），检查控制台是否有以下日志：

```
[CDP_RN_LOG] ✅ Switch 控件点击自动追踪（$AppClick）已启用
```

如未看到，重新执行 Hook 脚本：

```bash
node node_modules/qidian_cdp_sdk_rn/CDPRNHook.js
```

### Q: iOS 上 Switch 的 `cdp_isViewObjectIgnored` 不生效？

SDK 已在初始化阶段自动处理：通过 `ignoreViewType` 和 Method Swizzle 双重机制忽略 iOS 原生层对 `RCTSwitch`（`UISwitch`）的自动采集，由 JS 层统一处理 `$AppClick` 上报。如果仍然出现问题，请确认已重新编译 iOS 原生代码（修改了 `RNCDPAnalyticsModule.mm`）。

### Q: `maxCacheSize` 参数如何设置？

缓存上限参数按平台区分：

- **iOS**：使用 `maxCacheSizeIOS`，单位为**条数**，默认 1000 条，最大 5000 条
- **Android**：使用 `maxCacheSizeAndroid`，单位为**字节**，默认 32MB（`32 * 1024 * 1024`），最小 16MB

```typescript
cdpAnalytics.init('YOUR_APP_KEY', {
  maxCacheSizeIOS: 2000,                    // iOS: 最多缓存 2000 条
  maxCacheSizeAndroid: 64 * 1024 * 1024,    // Android: 最多缓存 64MB
});
```
