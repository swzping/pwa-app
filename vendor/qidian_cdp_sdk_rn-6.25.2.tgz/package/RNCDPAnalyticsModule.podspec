package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "RNCDPAnalyticsModule"
  s.version      = package["version"]
  s.summary      = "企点营销云 CDP 数据采集 React Native SDK"
  s.description  = <<-DESC
                  企点营销云 CDP 数据采集 React Native SDK，提供事件追踪、
                  用户属性设置、自动埋点等数据采集功能。
                   DESC
  s.homepage     = "https://qidian.qq.com"
  s.license      = { :type => "MIT" }
  s.author       = { "Tencent Qidian" => "qidian@tencent.com" }
  s.platform     = :ios, "13.0"
  s.source       = { :git => "", :tag => "v#{s.version}" }
  s.requires_arc = true

  s.source_files = "ios/RNCDPAnalyticsModule.{h,mm}"
  s.vendored_frameworks = "ios/CDP.framework"
  s.frameworks   = "Foundation", "UIKit"

  s.dependency   "React-Core"

  s.pod_target_xcconfig = {
    "CLANG_CXX_LANGUAGE_STANDARD" => "c++17",
    "GCC_PREPROCESSOR_DEFINITIONS" => "$(inherited) CDP_RN_SDK_VERSION=#{package["version"]}"
  }
end
