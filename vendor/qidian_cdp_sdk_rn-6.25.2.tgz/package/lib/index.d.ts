/**
 * 企点营销云 CDP 数据采集 React Native SDK - TypeScript 类型定义
 */

/**
 * 自动埋点事件类型枚举
 */
export declare enum AutoTrackEventType {
  /** 应用启动事件 */
  AppStart = 2,
  /** 应用退出事件 */
  AppExit = 4,
  /** 页面打开事件 */
  AppPageOpen = 8,
  /** 页面关闭事件 */
  AppPageClose = 16,
  /** 控件点击事件 */
  AppClick = 32,
  /** 所有事件 */
  All = 64,
}

/**
 * 数据加密方式枚举
 */
export declare enum EncryptType {
  /** Base64 加密 */
  BASE64 = 1,
  /** 先 Base64，再 AES 加密 */
  BASE64_AES = 2,
  /** 不加密，明文传输 */
  NONE = 3,
}

/**
 * 网络类型枚举
 */
export declare enum NetworkType {
  NONE = 0,
  TYPE_2G = 1,
  TYPE_3G = 2,
  TYPE_4G = 4,
  TYPE_WIFI = 8,
  TYPE_5G = 16,
  TYPE_ALL = 255,
}

/**
 * SDK 配置选项
 */
export interface CDPConfigOptions {
  /** 用户信息，键值对形式 */
  userInfos?: Record<string, string>;
  /** 数据上报请求的 Base URL */
  requestBaseUrl?: string;
  /** 自动埋点事件类型，使用 AutoTrackEventType 枚举值的按位或组合 */
  autoTrackEventType?: number;
  /** 数据加密方式 */
  encryptType?: EncryptType;
  /** 网络发送策略 */
  flushNetworkPolicy?: number;
  /**
   * 上报时间间隔，单位毫秒
   * 默认 15000ms，最小 5000ms，最大 600000ms
   */
  reportInterval?: number;
  /**
   * 本地缓存最大事件数目，达到阈值时发送数据
   * 默认 100 条，最小 0 条，最大 1000 条
   */
  reportMaxSize?: number;
  /** 单次上报最大条数，默认 50 条，最小 20 条，最大 100 条 */
  singleReportMaxSize?: number;
  /**
   * iOS 本地缓存上限（条数）
   * 本地缓存最多事件条数，默认 1000 条，最大 5000 条
   */
  maxCacheSizeIOS?: number;
  /**
   * Android 本地缓存上限（字节）
   * 设置本地缓存上限值，单位 byte，默认 32MB（32 * 1024 * 1024），
   * 最小 16MB（16 * 1024 * 1024），若小于 16MB，则按 16MB 处理
   */
  maxCacheSizeAndroid?: number;
  /** 是否开启 GZIP 数据压缩 */
  gzipEnabled?: boolean;
  /** 是否开启本地 log 打印 */
  logEnabled?: boolean;
  /** 自定义设备 ID，设置后优先使用 */
  deviceId?: string;
  /** 是否开启 IDFA 采集（仅 iOS） */
  enableIdfa?: boolean;
  /** 自定义语言标识 */
  customLanguage?: string;
}

/**
 * 属性类型
 */
export type PropertyValue = string | number | boolean;
export type Properties = Record<string, PropertyValue>;

/**
 * 页面配置接口
 *
 * - pageTitle: 页面标题，设置后会覆盖自动采集的 title 字段
 * - pageProperties: 页面自定义属性，会合并到 $AppPageView / $AppPageClose 事件属性中
 */
export interface CDPPageConfig {
  /** 页面标题，设置后覆盖自动采集的 title 字段 */
  pageTitle?: string;
  /** 页面自定义属性，会合并到页面事件属性中 */
  pageProperties?: Properties;
}

/**
 * 控件追踪属性接口
 *
 * 三个自定义追踪属性：
 * - cdp_ViewId: 控件的自定义元素ID，上报时作为 element_id 字段
 * - cdp_Properties: 控件的自定义属性，上报时合并到 $AppClick 事件属性中
 * - cdp_isViewObjectIgnored: 是否忽略该控件的 $AppClick 上报
 */
export interface CDPTrackProps {
  /** 控件的自定义元素ID，上报时作为 element_id 字段 */
  cdp_ViewId?: string;
  /** 控件的自定义属性，上报时合并到 $AppClick 事件属性中 */
  cdp_Properties?: Properties;
  /** 是否忽略该控件的 $AppClick 上报 */
  cdp_isViewObjectIgnored?: boolean;
}

/**
 * CDP 数据采集 SDK 类
 */
export declare class CDPAnalyticsSDK {
  /**
   * 初始化 SDK
   */
  init(appKey: string, configOptions?: CDPConfigOptions): void;

  /**
   * 埋点事件上报
   */
  track(eventName: string, properties?: Properties): void;

  /**
   * 页面浏览事件自动追踪（内部方法，由 CDPRNHook.js 自动调用，外部无需手动调用）
   * @internal
   */
  trackViewScreen(eventName: string, properties?: Properties): void;

  /**
   * 删除事件的所有属性
   */
  cleanProperties(eventType: AutoTrackEventType): void;

  /**
   * 给事件添加属性（如果属性已存在则覆盖，不存在则新增）
   */
  addProperties(properties: Properties, eventType: AutoTrackEventType): void;

  /**
   * 删除事件的某一条属性
   */
  removeProperty(key: string, eventType: AutoTrackEventType): void;

  /**
   * 获取事件的所有属性
   */
  getProperties(eventType: AutoTrackEventType): Promise<Properties>;

  // ==================== $AppPageView 黑白名单 ====================

  /**
   * 将页面添加到 $AppPageView 事件的黑名单
   */
  ignoreAutoTrackAppPageViewPages(pageNames: string[]): void;

  /**
   * 从 $AppPageView 黑名单中移除页面
   */
  resumeAutoTrackAppPageViewPages(pageNames: string[]): void;

  /**
   * 将页面添加到 $AppPageView 事件的白名单
   */
  interestAutoTrackAppPageViewPages(pageNames: string[]): void;

  /**
   * 从 $AppPageView 白名单中移除页面
   */
  boreAutoTrackAppPageViewPages(pageNames: string[]): void;

  // ==================== $AppPageClose 黑白名单 ====================

  /**
   * 将页面添加到 $AppPageClose 事件的黑名单
   */
  ignoreAutoTrackAppPageClosePages(pageNames: string[]): void;

  /**
   * 从 $AppPageClose 黑名单中移除页面
   */
  resumeAutoTrackAppPageClosePages(pageNames: string[]): void;

  /**
   * 将页面添加到 $AppPageClose 事件的白名单
   */
  interestAutoTrackAppPageClosePages(pageNames: string[]): void;

  /**
   * 从 $AppPageClose 白名单中移除页面
   */
  boreAutoTrackAppPageClosePages(pageNames: string[]): void;

  // ==================== 黑白名单查询 ====================

  /**
   * 判断页面是否在 $AppPageView 白名单中
   */
  isAutoTrackAppPageViewInterest(pageName: string): boolean;

  /**
   * 判断页面是否在 $AppPageView 黑名单中
   */
  isAutoTrackAppPageViewIgnored(pageName: string): boolean;

  /**
   * 判断页面是否在 $AppPageClose 白名单中
   */
  isAutoTrackAppPageCloseInterest(pageName: string): boolean;

  /**
   * 判断页面是否在 $AppPageClose 黑名单中
   */
  isAutoTrackAppPageCloseIgnored(pageName: string): boolean;

  // ==================== 自动埋点控制 ====================

  /**
   * 开启自动埋点上报
   */
  enableAutoTrack(eventType: AutoTrackEventType): void;

  /**
   * 关闭自动埋点上报
   */
  disableAutoTrack(eventType: AutoTrackEventType): void;

  /**
   * 启用 SDK
   */
  enableSDK(): void;

  /**
   * 禁用 SDK
   */
  disableSDK(): void;

  /**
   * 查询 SDK 禁用状态
   */
  isDisabled(): Promise<boolean>;

  /**
   * 设置用户身份信息
   */
  setUserInfos(userInfos: Record<string, string>): void;

  /**
   * 获取 SDK 版本号
   */
  getSDKVersion(): Promise<string>;

  /**
   * 为指定路由页面注册页面配置
   *
   * @param routeName 路由名称（react-navigation 的 Screen name）
   * @param config 页面配置（pageTitle 和 pageProperties）
   *
   * @example
   * // 设置页面标题
   * cdpAnalytics.registerPageConfig('ProductDetail', {
   *   pageTitle: '商品详情',
   * });
   *
   * // 设置页面标题和自定义属性
   * cdpAnalytics.registerPageConfig('ProductDetail', {
   *   pageTitle: '商品详情',
   *   pageProperties: { category: '电子产品', source: 'homepage' },
   * });
   */
  registerPageConfig(routeName: string, config: CDPPageConfig): void;

  /**
   * 取消指定路由页面的页面配置
   * @param routeName 路由名称
   */
  unregisterPageConfig(routeName: string): void;

  /**
   * 获取指定路由页面的页面配置
   * @param routeName 路由名称
   * @returns 页面配置，如未注册则返回 undefined
   */
  getPageConfig(routeName: string): CDPPageConfig | undefined;
}

declare const cdpAnalytics: CDPAnalyticsSDK;
export default cdpAnalytics;
