//
//  QDConstants.h
//  CDP
//
//  Created by di wang on 2023/6/6.
//

#ifndef QDConstants_h
#define QDConstants_h

/**
 * @abstract
 * 网络类型
 */
typedef NS_OPTIONS(NSInteger, QDAnalyticsNetworkType) {
    QDAnalyticsNetworkTypeNONE         = 0,
    QDAnalyticsNetworkType2G API_UNAVAILABLE(macos)    = 1 << 0,
    QDAnalyticsNetworkType3G API_UNAVAILABLE(macos)    = 1 << 1,
    QDAnalyticsNetworkType4G API_UNAVAILABLE(macos)    = 1 << 2,
    QDAnalyticsNetworkTypeWIFI     = 1 << 3,
    QDAnalyticsNetworkTypeALL      = 0xFF,
#ifdef __IPHONE_14_1
    QDAnalyticsNetworkType5G API_UNAVAILABLE(macos)   = 1 << 4
#endif
};






#endif /* QDConstants_h */
