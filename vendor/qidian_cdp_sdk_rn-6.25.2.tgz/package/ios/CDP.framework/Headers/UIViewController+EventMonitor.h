//
//  UIViewController+EventMonitor.h
//  SDKTest
//
//  Created by di wang on 2021/9/9.
// Copyright (c) jobsdiwang Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@interface UIViewController (EventMonitor)

/// 页面标题，如果设置，则会覆盖公共属性title，如果未设置，则title默认取导航栏(UIVIewController.navigationItem.title)，如果导航栏标题也为空，则取页面的类名
@property (nonatomic, strong, nullable)NSString  *cdp_PageTitle;

/// 页面自定义属性
@property (nonatomic, strong, nullable)NSDictionary *cdp_PageProperties;

@end

NS_ASSUME_NONNULL_END
