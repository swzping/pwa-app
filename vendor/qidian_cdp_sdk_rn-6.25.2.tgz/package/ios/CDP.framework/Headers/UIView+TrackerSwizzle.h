//
//  UIView+TrackerSwizzle.h
//  CDP
//
//  Created by di wang on 2023/12/14.
//

#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface UIView (TrackerSwizzle)


/// 控件的元素id，由业务侧set
@property(nonatomic,  copy) IBInspectable NSString     *cdp_ViewId;

/// 业务侧给某个控件对象设置的属性
@property(nonatomic,strong) NSDictionary *cdp_Properties;

/// 是否忽略上报
@property(nonatomic,assign) IBInspectable BOOL  cdp_isViewObjectIgnored;

/// 手动触发控件事件上报
- (void)cdp_AutoTrackEventClick;

@end


NS_ASSUME_NONNULL_END
