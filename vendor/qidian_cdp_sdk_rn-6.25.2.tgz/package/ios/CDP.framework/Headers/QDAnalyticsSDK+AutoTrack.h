//
//  QDAnalyticsSDK+AutoTrack.h
//  CDP
//
//  Created by Robin on 2024/5/28.
//
 
#import <CDP/QDAnalyticsSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QDAnalyticsSDK (AutoTrack)


/// 开启全埋点上报
/// - Parameter trackEventType: 事件类型，参考AutoTrackEventType
- (void)enableAutoTrackEventType:(AutoTrackEventType)trackEventType;

/// 关闭全埋点上报
/// - Parameter trackEventType: 事件类型，参考AutoTrackEventType
- (void)disableAutoTrackEventType:(AutoTrackEventType)trackEventType;

#pragma mark - ignore View

/**
忽略某类型控件的上报
@param type 对应的控件类型,比如: [UIButton class]
*/
- (void)ignoreViewType:(Class)type;

/**
忽略某类型控件的上报
@param type 对应的控件类型,比如: [UIButton class]
*/
- (void)resumeViewType:(Class)type;

/**
获取所有忽略的控件类型集合
*/
- (NSArray *)getIgnoreViewTypeList;


#pragma mark - ignore ViewController AppPageView

/**
 判断某个页面的AppPageView事件是否被忽略上报
 @param controller 对应的Controller类名字符串
*/
- (BOOL)isControllerAutoTrackPageViewIgnored:(NSString *)controller;

/**
 忽略某个页面的AppPageView事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)ignoreAutoTrackPageViewController:(NSString *)controller;

/**
 忽略某些页面的AppPageView上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)ignoreAutoTrackPageViewControllers:(NSArray<NSString *> *)controllers;

/**
 恢复某个页面的AppPageView事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)resumeAutoTrackPageViewController:(NSString *)controller;

/**
 恢复某些页面的AppPageView事件上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)resumeAutoTrackPageViewControllers:(NSArray<NSString *> *)controllers;


#pragma mark - ignore ViewController AppPageClose

/**
 判断某个页面的AppPageClose事件是否被忽略上报
 @param controller 对应的Controller类名字符串
*/
- (BOOL)isControllerAutoTrackPageCloseIgnored:(NSString *)controller;

/**
 忽略某个页面的AppPageClose事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)ignoreAutoTrackPageCloseController:(NSString *)controller;

/**
 忽略某些页面的AppPageClose上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)ignoreAutoTrackPageCloseControllers:(NSArray<NSString *> *)controllers;

/**
 恢复某个页面的AppPageClose事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)resumeAutoTrackPageCloseController:(NSString *)controller;

/**
 恢复某些页面的AppPageClose事件上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)resumeAutoTrackPageCloseControllers:(NSArray<NSString *> *)controllers;


#pragma mark - ignore ViewController AppClick

/**
 判断某个页面的AppClick事件是否被忽略上报
 @param controller 对应的Controller类名字符串
*/
- (BOOL)isControllerAutoTrackAppClickIgnored:(NSString *)controller;

/**
 忽略某个页面的AppClick事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)ignoreAutoTrackAppClickController:(NSString *)controller;

/**
 忽略某些页面的AppClick上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)ignoreAutoTrackAppClickControllers:(NSArray<NSString *> *)controllers;

/**
 恢复某个页面的AppClick事件上报
 @param controller 对应的Controller类名字符串
*/
- (void)resumeAutoTrackAppClickController:(NSString *)controller;

/**
 恢复某些页面的AppClick事件上报
 @param controllers 对应的Controller类名字符串数组
*/
- (void)resumeAutoTrackAppClickControllers:(NSArray<NSString *> *)controllers;

#pragma mark - Include ViewController AppPageView
/**
 判断某个页面的AppPageView事件是否在白名单中
 @param controller 对应的Controller类名字符串
*/
- (BOOL)isControllerAutoTrackPageViewInclude:(NSString *)controller;

/**
 将某个页面的AppPageView事件加入白名单（如果设置了白名单，则仅上报白名单里的页面）
 @param controller 对应的Controller类名字符串
*/
- (void)includeAutoTrackPageViewController:(NSString *)controller;

/**
 将某些页面的AppPageView事件加入白名单（如果设置了白名单，则仅上报白名单里的页面）
 @param controllers 对应的Controller类名字符串数组
*/
- (void)includeAutoTrackPageViewControllers:(NSArray<NSString *> *)controllers;

/**
 从白名单中删除某个页面的AppPageView事件
 @param controller 对应的Controller类名字符串
*/
- (void)removeAutoTrackPageViewController:(NSString *)controller;

/**
 从白名单中删除某个页面的AppPageView事件
 @param controllers 对应的Controller类名字符串数组
*/
- (void)removeAutoTrackPageViewControllers:(NSArray<NSString *> *)controllers;

#pragma mark - Include ViewController AppPageClose

/**
 判断某个页面的AppPageClose事件是否在白名单中
 @param controller 对应的Controller类名字符串
*/
- (BOOL)isControllerAutoTrackPageCloseInclude:(NSString *)controller;

/**
 将某个页面的AppPageClose事件加入白名单（如果设置了白名单，则仅上报白名单里的页面）
 @param controller 对应的Controller类名字符串
*/
- (void)includeAutoTrackPageCloseController:(NSString *)controller;

/**
 将某些页面的AppPageClose事件加入白名单（如果设置了白名单，则仅上报白名单里的页面）
 @param controllers 对应的Controller类名字符串数组
*/
- (void)includeAutoTrackPageCloseControllers:(NSArray<NSString *> *)controllers;

/**
 从白名单中删除某个页面的AppPageClose事件
 @param controller 对应的Controller类名字符串
*/
- (void)removeAutoTrackPageCloseController:(NSString *)controller;

/**
 从白名单中删除某个页面的AppPageClose事件
 @param controllers 对应的Controller类名字符串数组
*/
- (void)removeAutoTrackPageCloseControllers:(NSArray<NSString *> *)controllers;

#pragma mark - Util
/**
 获取所有ignore页面的集合
 @return @{@"$AppClick": @[], @"$AppPageView": @[], @"$AppPageClose": @[]}
*/
- (NSDictionary *)getIgnoreControllerList;

/**
 获取所有ignore页面的集合
 @return @{@"$AppPageView": @[], @"$AppPageClose": @[]}
*/
- (NSDictionary *)getIncludeControllerList;
@end

NS_ASSUME_NONNULL_END
