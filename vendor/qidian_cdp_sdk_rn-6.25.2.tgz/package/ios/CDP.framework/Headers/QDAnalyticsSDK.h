//
//  QDAnalyticsSDK.h
//  SDKTest
//  CDP v6.23.2.1 Update Date: 2026-04-17 By: jaylongliu
//  Created by di wang on 2021/9/8.
//  Copyright (c) jobsdiwang Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CDP/QDConfigOptions.h>


NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN NSString * const kCDPSDKVersion;

/**
  提供给外部初始化SDK、和事件上报的类
 */
@interface QDAnalyticsSDK : NSObject


//创建对应实例
+ (instancetype)sharedInstance;

/**
 初始化
 @param appkey (开发者在管理平台申请的key)
 @param configOptions (配置的基本信息)
 */
- (void)initWithAppkey:(NSString *)appkey andConfigOptions:(QDConfigOptions *)configOptions;

 
/**
 给事件设置属性
 @param dic 所传递的属性
 @param event 需要设置的事件

  属性优先级：单个事件设置的属性优先级 > 给所有事件设置的属性
  比如给AutoTrackEventType_App_PageOpen 事件设置属性@{@"age":(18)},
  再给AutoTrackEventTypeAll 即所有事件设置属性@{@"age":(20)} ,则AutoTrackEventType_App_PageOpen事件上报时候key=age，value取值为18
*/
- (void)setProperties:(NSDictionary *)dic forEvent:(AutoTrackEventType)event;


/**
 删除事件的所有属性
 @param event 需要设置的事件
*/
- (void)cleanPropertiesForEvent:(AutoTrackEventType)event;


/**
 给事件新增属性 (注： 如果事件原来有这个属性，则会执行更新操作)
 @param dic 所传递的属性
 @param event 需要操作的事件
*/
- (void)addProperties:(NSDictionary *)dic forEvent:(AutoTrackEventType)event;


/**
 删除事件的某一条属性
 @param key 需要删除属性所对应的key
 @param event 需要设置的事件
*/
- (void)removePropertieBykey:(NSString *)key forEvent:(AutoTrackEventType)event;


/**
 获取事件的所有属性
 @param event 需要设置的事件
*/
- (NSMutableDictionary *)getPropertiesForEvent:(AutoTrackEventType)event;


///提供给前端的交互数据
- (NSMutableDictionary *)obtainCdpAppH5Bridge;


/**
 埋点事件上报
 @param event 事件名称(管理平台配置)
 @param dic 事件属性字典(管理平台配置,如果平台配置的属性是日期或者日期与时间类型，请在dic中将value设置为对应毫秒时间戳类型)
*/
- (void)reportEvent:(NSString *)event andParameters:(NSMutableDictionary *)dic;

/**
 启用SDK，启用SDK后，恢复采集上报数据
 */
- (void)enableSDK;

/**
 禁用SDK，禁用SDK后，不再采集上报任何数据
 */
- (void)disableSDK;

/**
 查询当前SDK禁用状态，YES表示SDK禁用，NO表示SDK启用，默认SDK为启用状态
 */
- (BOOL)getDisabled;

@end

NS_ASSUME_NONNULL_END
