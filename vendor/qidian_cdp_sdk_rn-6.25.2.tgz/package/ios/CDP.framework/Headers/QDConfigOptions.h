//
//  QDConfigOptions.h
//  SDKTest
//
//  Created by di wang on 2021/9/8.
// Copyright (c) jobsdiwang Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QDConstants.h"

typedef enum {
    ///base64加密
    ENCRYPT_type_BASE64 = 1,
    ///aes加密
    ENCRYPT_type_ASE,
    ///不加密
    ENCRYPT_type_NULL
}ENCRY_TYPE;


typedef NS_OPTIONS(NSInteger,AutoTrackEventType) {
    ///启动事件
    AutoTrackEventTypeAppStart      = 1 <<1,
    ///退出事件
    AutoTrackEventTypeAppExit       = 1 <<2,
    ///页面打开事件
    AutoTrackEventTypeAppPageOpen   = 1 <<3,
    ///页面关闭事件
    AutoTrackEventTypeAppPageClose  = 1 <<4,
    ///页面控件点击事件
    AutoTrackEventTypeAppClick  = 1 <<5,
    ///所有事件
    AutoTrackEventTypeAll   = 1 <<6
};


NS_ASSUME_NONNULL_BEGIN

/**
  SDK config
 */
@interface QDConfigOptions : NSObject

//创建对应实例
+ (instancetype)sharedInstance;

///用户在平台自定义的身份字段，可以支持多个k-v格式
@property (nonatomic,strong)NSDictionary    *userInfos;

///上报的地址，SDK有默认地址,开发同学也可根据需要重新传入，没有则不传
@property (nonatomic,copy)NSString           *requesBaseUrl;

///开启自动上报的事件类型(eg:  AutoTrackEventType_App_Start | AutoTrackEventType_App_Exit)
@property (nonatomic, assign)AutoTrackEventType         autoTrackEventType;

///数据请求加密方式( 1: base64      2: AES    3: 不加密 ,  默认2 ASE加密)
@property (nonatomic,assign)ENCRY_TYPE         encryType;

/*
  设置数据上报时候的网络发送策略
  默认3G、4G、5G、WI-FI 环境下都会尝试上报
 */
@property (nonatomic, assign) QDAnalyticsNetworkType flushNetworkPolicy;

/*
   时间间隔，默认15*1000ms，最大600 * 1000ms，最小5 * 1000ms
   都会检查如下条件，以判断是否向服务器上传数据:
   1. 是否 WIFI/3G/4G/5G 网络
   2. 是否满足以下数据发送条件之一:
    1) 与上次发送的时间间隔是否大于 reportInterval
    2) 本地缓存上报条数是否达到reportMaxSize
   如果满足这两个条件之一，则向服务器发送一次数据；如果都不满足，则把数据加入到队列中，等待下次检查时把整个队列的内容一并发送。
 */
@property (nonatomic,assign)NSInteger        reportInterval;


/*
    本地缓存的最大事件数目，当累积日志量达到阈值时发送数据，
     默认为100条，最小为0条，最大为1000条
    都会检查如下条件，以判断是否向服务器上传数据:
    1. 是否 WIFI/3G/4G/5G 网络
    2. 是否满足以下数据发送条件之一
        1) 与上次发送的时间间隔是否大于 reportInterval
        2) 本地缓存日志数目是否达到 reportMaxSize
    如果满足这两个条件之一，则向服务器发送一次数据；如果都不满足，则把数据加入到队列中，等待下次检查时把整个队列的内容一并发送。
    
 */
@property (nonatomic,assign)NSInteger        reportMaxSize;

/// 单次上报最大条数，默认50条，最小20条最大100条
@property (nonatomic,assign)NSInteger        singleReportMaxSize;

/// 设置本地缓存最多事件条数，默认为1000条, 最大5000条
@property (nonatomic,assign)NSInteger       maxCacheSize;

/// 是否开启GZIP数据压缩
@property (nonatomic,assign)BOOL            mGZIPEnabled;

/// 是否开启本地log打印
@property (nonatomic,assign)BOOL            logEnabled;

/// 允许用户直接指定设备ID，如果设置了该属性，则优先使用用户设置的值作为上报的设备ID，否则默认按照idfa > idfv > uuid的顺序生成设备ID。默认为空。
@property (nonatomic, strong, nullable) NSString *deviceId;

/// 是否允许获取idfa，默认为YES，如果为否，则在获取设备ID时不会获取idfa。如果设置了deviceId属性，则该属性不生效。
@property (nonatomic, assign) BOOL enableIdfa;

/// 自定义语言，格式：en_US,zh_CN，如果不设置，默认取系统语言
@property (nonatomic, strong, nullable) NSString *customLanguage;

@end

NS_ASSUME_NONNULL_END
