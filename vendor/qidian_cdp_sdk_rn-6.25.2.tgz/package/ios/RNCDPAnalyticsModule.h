//
//  RNCDPAnalyticsModule.h
//  RNCDPAnalyticsModule
//
//  企点营销云 CDP 数据采集 React Native SDK - iOS 原生模块
//  Copyright © Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

@interface RNCDPAnalyticsModule : NSObject<RCTBridgeModule>

extern NSString *const kCDPReactNativeSDKVersion;

@end
