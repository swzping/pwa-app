//
//  RNCDPAnalyticsModule.mm
//  RNCDPAnalyticsModule
//
//  企点营销云 CDP 数据采集 React Native SDK - iOS 原生模块实现
//  Copyright © Tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Either turn on ARC for the project or use -fobjc-arc flag on this file.
#endif

#import "RNCDPAnalyticsModule.h"

#import <objc/runtime.h>

#if __has_include(<CDP/QDAnalyticsSDK.h>)
#import <CDP/QDAnalyticsSDK.h>
#import <CDP/QDAnalyticsSDK+AutoTrack.h>
#import <CDP/QDConfigOptions.h>
#import <CDP/UIView+TrackerSwizzle.h>
#else
#import "QDAnalyticsSDK.h"
#import "QDAnalyticsSDK+AutoTrack.h"
#import "QDConfigOptions.h"
#import "UIView+TrackerSwizzle.h"
#endif

// 版本号由 podspec 从 package.json 统一注入
#define CDP_STRINGIFY(x) #x
#define CDP_TOSTRING(x) CDP_STRINGIFY(x)

#ifdef CDP_RN_SDK_VERSION
NSString *const kCDPReactNativeSDKVersion = @"react_native:" CDP_TOSTRING(CDP_RN_SDK_VERSION);
#else
#error "CDP_RN_SDK_VERSION is not defined. Check podspec GCC_PREPROCESSOR_DEFINITIONS."
#endif

@implementation RNCDPAnalyticsModule {
    BOOL _logEnabled;
}

RCT_EXPORT_MODULE(RNCDPAnalyticsModule)

#pragma mark - 初始化

/**
 * 初始化 SDK
 * @param appKey 开发者在管理平台申请的 key
 * @param configOptions 配置选项字典
 */
RCT_EXPORT_METHOD(init:(NSString *)appKey configOptions:(NSDictionary *)configDict) {
    @try {
        QDConfigOptions *options = [QDConfigOptions sharedInstance];

        // 用户身份信息
        if (configDict[@"userInfos"] && [configDict[@"userInfos"] isKindOfClass:[NSDictionary class]]) {
            options.userInfos = configDict[@"userInfos"];
        }

        // 上报地址
        if (configDict[@"requestBaseUrl"] && [configDict[@"requestBaseUrl"] isKindOfClass:[NSString class]]) {
            options.requesBaseUrl = configDict[@"requestBaseUrl"];
        }

        // 自动埋点事件类型
        if (configDict[@"autoTrackEventType"]) {
            options.autoTrackEventType = [configDict[@"autoTrackEventType"] integerValue];
        }

        // 加密方式
        if (configDict[@"encryptType"]) {
            options.encryType = (ENCRY_TYPE)[configDict[@"encryptType"] integerValue];
        }

        // 网络发送策略
        if (configDict[@"flushNetworkPolicy"]) {
            options.flushNetworkPolicy = [configDict[@"flushNetworkPolicy"] integerValue];
        }

        // 上报时间间隔
        if (configDict[@"reportInterval"]) {
            options.reportInterval = [configDict[@"reportInterval"] integerValue];
        }

        // 本地缓存最大事件数
        if (configDict[@"reportMaxSize"]) {
            options.reportMaxSize = [configDict[@"reportMaxSize"] integerValue];
        }

        // 单次上报最大条数
        if (configDict[@"singleReportMaxSize"]) {
            options.singleReportMaxSize = [configDict[@"singleReportMaxSize"] integerValue];
        }

        // 本地缓存最大条数
        if (configDict[@"maxCacheSizeIOS"]) {
            options.maxCacheSize = [configDict[@"maxCacheSizeIOS"] integerValue];
        }

        // GZIP 压缩
        if (configDict[@"gzipEnabled"]) {
            options.mGZIPEnabled = [configDict[@"gzipEnabled"] boolValue];
        }

        // 日志开关
        if (configDict[@"logEnabled"]) {
            options.logEnabled = [configDict[@"logEnabled"] boolValue];
            _logEnabled = options.logEnabled;
        }

        // 自定义设备 ID
        if (configDict[@"deviceId"] && [configDict[@"deviceId"] isKindOfClass:[NSString class]]) {
            options.deviceId = configDict[@"deviceId"];
        }

        // IDFA 开关
        if (configDict[@"enableIdfa"]) {
            options.enableIdfa = [configDict[@"enableIdfa"] boolValue];
        }

        // 自定义语言
        if (configDict[@"customLanguage"] && [configDict[@"customLanguage"] isKindOfClass:[NSString class]]) {
            options.customLanguage = configDict[@"customLanguage"];
        }

        [[QDAnalyticsSDK sharedInstance] initWithAppkey:appKey andConfigOptions:options];

        // React Native 环境下，页面浏览/关闭事件由 CDPRNHook.js 在 JS 层通过
        // react-navigation 路由变化来采集（能获取到真实的 RN 页面名称和参数）。
        // react-native-screens 库会为每个 RN 页面创建原生 UIViewController（RNSScreen、
        // RNSViewController 等），CDP iOS SDK 的自动采集会 Hook 这些 ViewController 的
        // viewDidAppear:/viewDidDisappear: 方法，导致页面事件被重复上报。
        // 因此需要忽略这些 RN 相关 ViewController 的自动采集，避免重复。
        NSArray *rnViewControllers = @[
            @"RNSScreen",                // react-native-screens 的页面 VC
            @"RNSViewController",        // react-native-screens 的容器 VC
            @"RNSNavigationController",  // react-native-screens 的导航控制器
            @"RCTModalHostViewController", // RN 内置 Modal 的 VC
            @"RCTWrapperViewController", // RN 内置包装 VC
            @"RCTRedBoxExtraDataViewController", // RN 调试红屏 VC
        ];
        [[QDAnalyticsSDK sharedInstance] ignoreAutoTrackPageViewControllers:rnViewControllers];
        [[QDAnalyticsSDK sharedInstance] ignoreAutoTrackPageCloseControllers:rnViewControllers];

        // 忽略 RN 中 Switch 控件的原生 $AppClick 自动采集。
        // Switch 的 $AppClick 由 CDPRNHook.js 在 JS 层统一处理，这样 RN 组件上
        // 设置的 cdp_isViewObjectIgnored 等 CDP 属性才能正确生效。
        // 如果不忽略，iOS 原生 SDK 通过 UIControl.sendAction:to:forEvent: Method Swizzle
        // 拦截的事件无法读取 JS 层的 CDP 属性，导致 cdp_isViewObjectIgnored 不生效。
        //
        // 方案1：通过 ignoreViewType 忽略（依赖 SDK 内部 _ignoredViewtypes 检查）
        [[QDAnalyticsSDK sharedInstance] ignoreViewType:[UISwitch class]];
        Class rctSwitchClass = NSClassFromString(@"RCTSwitch");
        if (rctSwitchClass) {
            [[QDAnalyticsSDK sharedInstance] ignoreViewType:rctSwitchClass];
        }

        // 方案2（兜底）：直接设置所有 RCTSwitch 实例的 cdp_isViewObjectIgnored=YES。
        // 原生 SDK 的 TR_sendAction:to:forEvent: 在上报前会检查 view 的
        // cdp_isViewObjectIgnored 属性，如果为 YES 则跳过上报。
        // 通过 Method Swizzle RCTSwitch 的 didMoveToWindow 方法，在 Switch 被添加到
        // 视图层级时自动设置该属性，确保所有 RCTSwitch 实例都被原生 SDK 忽略。
        if (rctSwitchClass) {
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                SEL originalSel = @selector(didMoveToWindow);
                Method originalMethod = class_getInstanceMethod(rctSwitchClass, originalSel);
                if (originalMethod) {
                    __block IMP originalIMP = method_getImplementation(originalMethod);
                    IMP newIMP = imp_implementationWithBlock(^(UIView *self) {
                        // 设置忽略标记，让原生 SDK 跳过此 view
                        self.cdp_isViewObjectIgnored = YES;
                        // 调用原始实现
                        if (originalIMP) {
                            ((void (*)(id, SEL))originalIMP)(self, originalSel);
                        }
                    });
                    method_setImplementation(originalMethod, newIMP);
                }
            });
        }
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] init error: %@", exception);
    }
}

#pragma mark - 事件追踪

/**
 * 埋点事件上报
 */
RCT_EXPORT_METHOD(track:(NSString *)eventName properties:(NSDictionary *)properties) {
    @try {
        NSMutableDictionary *mutableProps = properties ? [properties mutableCopy] : [NSMutableDictionary dictionary];
        [[QDAnalyticsSDK sharedInstance] reportEvent:eventName andParameters:mutableProps];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] track error: %@", exception);
    }
}

/**
 * 控件点击事件（自动追踪专用，供 CDPRNHook.js 注入的 $AppClick 代码调用）
 * @param properties 点击事件属性（element_type、element_content、element_path 等）
 *
 * 上报 $AppClick 事件前检查 autoTrackEventType 中 AppClick 开关是否开启。
 */
RCT_EXPORT_METHOD(trackAppClick:(NSDictionary *)properties) {
    @try {
        // 检查 autoTrackEventType 开关
        AutoTrackEventType currentAutoTrackType = [QDConfigOptions sharedInstance].autoTrackEventType;
        if (!(currentAutoTrackType & AutoTrackEventTypeAppClick) &&
            !(currentAutoTrackType & AutoTrackEventTypeAll)) {
            return;
        }

        NSMutableDictionary *mutableProps = properties ? [properties mutableCopy] : [NSMutableDictionary dictionary];
        [[QDAnalyticsSDK sharedInstance] reportEvent:@"$AppClick" andParameters:mutableProps];
        [self logDebug:@"$AppClick: %@ | %@ | %@",
              mutableProps[@"element_type"] ?: @"",
              mutableProps[@"element_content"] ?: @"",
              mutableProps[@"element_path"] ?: @""];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] trackAppClick error: %@", exception);
    }
}

/**
 * 页面浏览/关闭事件（自动追踪专用，供 CDPRNHook.js 调用）
 * @param eventName 事件名称（$AppPageView 或 $AppPageClose）
 * @param properties 页面属性
 *
 * 注意：此方法会检查 autoTrackEventType 开关，
 * 仅在对应的事件类型开关开启时才上报，避免用户关闭开关后仍然上报。
 */
RCT_EXPORT_METHOD(trackViewScreen:(NSString *)eventName properties:(NSDictionary *)properties) {
    @try {
        // 检查 autoTrackEventType 开关
        AutoTrackEventType currentAutoTrackType = [QDConfigOptions sharedInstance].autoTrackEventType;
        if ([eventName isEqualToString:@"$AppPageView"]) {
            // 检查页面打开事件开关（AppPageOpen = 1 << 3）
            if (!(currentAutoTrackType & AutoTrackEventTypeAppPageOpen) &&
                !(currentAutoTrackType & AutoTrackEventTypeAll)) {
                [self logDebug:@"trackViewScreen: $AppPageView 事件开关已关闭，跳过上报"];
                return;
            }
        } else if ([eventName isEqualToString:@"$AppPageClose"]) {
            // 检查页面关闭事件开关（AppPageClose = 1 << 4）
            if (!(currentAutoTrackType & AutoTrackEventTypeAppPageClose) &&
                !(currentAutoTrackType & AutoTrackEventTypeAll)) {
                [self logDebug:@"trackViewScreen: $AppPageClose 事件开关已关闭，跳过上报"];
                return;
            }
        }

        NSMutableDictionary *mutableProps = properties ? [properties mutableCopy] : [NSMutableDictionary dictionary];
        [[QDAnalyticsSDK sharedInstance] reportEvent:eventName andParameters:mutableProps];
        [self logDebug:@"%@: url=%@, title=%@, referrer=%@, dr=%@",
              eventName,
              mutableProps[@"url"] ?: @"",
              mutableProps[@"title"] ?: @"",
              mutableProps[@"referrer"] ?: @"",
              mutableProps[@"dr"] ?: @""];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] trackViewScreen error: %@", exception);
    }
}

/**
 * 页面浏览事件（手动上报）
 * @param pageName 页面名称
 * @param properties 页面属性（url、title、referrer 等）
 */
RCT_EXPORT_METHOD(trackPageOpen:(NSString *)pageName properties:(NSDictionary *)properties) {
    @try {
        NSMutableDictionary *mutableProps = properties ? [properties mutableCopy] : [NSMutableDictionary dictionary];
        // 以 pageName 作为 url 和 title
        if (![mutableProps objectForKey:@"url"]) {
            [mutableProps setObject:pageName ?: @"" forKey:@"url"];
        }
        if (![mutableProps objectForKey:@"title"]) {
            [mutableProps setObject:pageName ?: @"" forKey:@"title"];
        }
        [[QDAnalyticsSDK sharedInstance] reportEvent:@"$AppPageView" andParameters:mutableProps];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] trackPageOpen error: %@", exception);
    }
}

/**
 * 页面关闭事件（手动上报）
 */
RCT_EXPORT_METHOD(trackPageClose:(NSString *)pageName properties:(NSDictionary *)properties) {
    @try {
        NSMutableDictionary *mutableProps = properties ? [properties mutableCopy] : [NSMutableDictionary dictionary];
        if (![mutableProps objectForKey:@"url"]) {
            [mutableProps setObject:pageName ?: @"" forKey:@"url"];
        }
        if (![mutableProps objectForKey:@"title"]) {
            [mutableProps setObject:pageName ?: @"" forKey:@"title"];
        }
        [[QDAnalyticsSDK sharedInstance] reportEvent:@"$AppPageClose" andParameters:mutableProps];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] trackPageClose error: %@", exception);
    }
}

#pragma mark - 事件属性管理

/**
 * 清除事件的所有属性
 */
RCT_EXPORT_METHOD(cleanProperties:(nonnull NSNumber *)eventType) {
    @try {
        [[QDAnalyticsSDK sharedInstance] cleanPropertiesForEvent:(AutoTrackEventType)[eventType integerValue]];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] cleanProperties error: %@", exception);
    }
}

/**
 * 新增事件属性
 */
RCT_EXPORT_METHOD(addProperties:(NSDictionary *)properties eventType:(nonnull NSNumber *)eventType) {
    @try {
        [[QDAnalyticsSDK sharedInstance] addProperties:properties forEvent:(AutoTrackEventType)[eventType integerValue]];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] addProperties error: %@", exception);
    }
}

/**
 * 删除事件的某一条属性
 */
RCT_EXPORT_METHOD(removeProperty:(NSString *)key eventType:(nonnull NSNumber *)eventType) {
    @try {
        [[QDAnalyticsSDK sharedInstance] removePropertieBykey:key forEvent:(AutoTrackEventType)[eventType integerValue]];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] removeProperty error: %@", exception);
    }
}

/**
 * 获取事件的所有属性
 */
RCT_EXPORT_METHOD(getProperties:(nonnull NSNumber *)eventType
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
    @try {
        NSMutableDictionary *properties = [[QDAnalyticsSDK sharedInstance] getPropertiesForEvent:(AutoTrackEventType)[eventType integerValue]];
        resolve(properties ?: @{});
    } @catch (NSException *exception) {
        reject(@"CDPRNHook", @"getProperties failed",
               [NSError errorWithDomain:@"CDPRNHook" code:-1
                               userInfo:@{NSLocalizedDescriptionKey: exception.reason ?: @"unknown error"}]);
    }
}

#pragma mark - 自动埋点控制

/**
 * 开启自动埋点
 */
RCT_EXPORT_METHOD(enableAutoTrack:(nonnull NSNumber *)eventType) {
    @try {
        [[QDAnalyticsSDK sharedInstance] enableAutoTrackEventType:(AutoTrackEventType)[eventType integerValue]];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] enableAutoTrack error: %@", exception);
    }
}

/**
 * 关闭自动埋点
 */
RCT_EXPORT_METHOD(disableAutoTrack:(nonnull NSNumber *)eventType) {
    @try {
        [[QDAnalyticsSDK sharedInstance] disableAutoTrackEventType:(AutoTrackEventType)[eventType integerValue]];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] disableAutoTrack error: %@", exception);
    }
}

#pragma mark - SDK 状态控制

/**
 * 启用 SDK
 */
RCT_EXPORT_METHOD(enableSDK) {
    @try {
        [[QDAnalyticsSDK sharedInstance] enableSDK];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] enableSDK error: %@", exception);
    }
}

/**
 * 禁用 SDK
 */
RCT_EXPORT_METHOD(disableSDK) {
    @try {
        [[QDAnalyticsSDK sharedInstance] disableSDK];
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] disableSDK error: %@", exception);
    }
}

/**
 * 获取 SDK 禁用状态
 */
RCT_EXPORT_METHOD(isDisabled:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
    @try {
        BOOL disabled = [[QDAnalyticsSDK sharedInstance] getDisabled];
        resolve(@(disabled));
    } @catch (NSException *exception) {
        reject(@"CDPRNHook", @"isDisabled failed",
               [NSError errorWithDomain:@"CDPRNHook" code:-1
                               userInfo:@{NSLocalizedDescriptionKey: exception.reason ?: @"unknown error"}]);
    }
}

#pragma mark - 数据发送控制

#pragma mark - 用户身份管理

/**
 * 设置用户身份信息
 */
RCT_EXPORT_METHOD(setUserInfos:(NSDictionary *)userInfos) {
    @try {
        [QDConfigOptions sharedInstance].userInfos = userInfos;
    } @catch (NSException *exception) {
        NSLog(@"[CDP_RN_LOG] setUserInfos error: %@", exception);
    }
}

/**
 * 获取 SDK 版本号
 */
RCT_EXPORT_METHOD(getSDKVersion:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject) {
    @try {
        resolve(kCDPReactNativeSDKVersion);
    } @catch (NSException *exception) {
        reject(@"CDPRNHook", @"getSDKVersion failed",
               [NSError errorWithDomain:@"CDPRNHook" code:-1
                               userInfo:@{NSLocalizedDescriptionKey: exception.reason ?: @"unknown error"}]);
    }
}

#pragma mark - 工具方法

/**
 * 调试日志输出，仅在 logEnabled 为 true 时打印
 * @param format 日志格式字符串
 */
- (void)logDebug:(NSString *)format, ... NS_FORMAT_FUNCTION(1,2) {
    if (_logEnabled) {
        va_list args;
        va_start(args, format);
        NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
        va_end(args);
        NSLog(@"[CDP_RN_LOG] %@", message);
    }
}

@end
